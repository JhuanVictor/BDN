package com.bdn.bdnapi.bdnapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BdnApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BdnApiApplication.class, args);
	}

}
